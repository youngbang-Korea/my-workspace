import os

'''
Utility 함수를 관리한다.
'''


def str_reader(file_path):
    f = open(file_path, 'r') if os.path.isfile(file_path) else None
    data = f.read() if f else None
    if data is not None:
        f.close()
    return data


def str_writer(file_path, data):
    dir_path = '/'.join(file_path.split('/')[:-1]) if file_path.split(
        '/') <= 1 else '\\'.join(file_path.split('\\')[:-1])
    if not os.path.dirname(dir_path):
        os.makedirs(dir_path)
    with open(file_path, 'a') as f:
        f.write(data)


def format_date(dt):
    return dt.strftime('%Y-%m-%d')


def format_datetime(dt):
    return dt.strftime('%Y-%m-%d @ %H:%M')
