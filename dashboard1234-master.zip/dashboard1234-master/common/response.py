import flask
import json
from models import config_yaml

'''
Response 기본적인 함수를 제공한다.
'''


def ok(data=None, code=20000, raw=False):
    if raw:
        res = data or {}
    else:
        res = json.dumps({
            'code': code,
            'data': {} if data is None else data
        })
    return _make_response(res, code)


def error(code, message=None):
    if not message:
        message = config_yaml['ERROR_CODE'][code]

    res = json.dumps({
        'code': code,
        'message': message
    })
    return _make_response(res, code)


def _make_response(data, code):
    status_code = int(code / 100)
    resp = flask.make_response(data, status_code)
    resp.headers['Content-Type'] = 'application/json'
    return resp
