from flask import Blueprint, render_template

'''
Flask에서 일어나는 Error에 대해 핸들링한다.
'''

bp = Blueprint('error', __name__)


@bp.app_errorhandler(403)
def forbidden(err):
    return render_template('error/403.html')


@bp.app_errorhandler(404)
def page_not_found(err):
    return render_template('error/404.html')


@bp.app_errorhandler(410)
def gone(err):
    return render_template('error/410.html')


@bp.app_errorhandler(500)
def internal_server_error(err):
    return render_template('error/500.html')
