'''
Filter 날짜 형식 필터 함수를 제공한다.
'''


def format_datetime(value, fmt='%Y-%m-%d %H:%M'):
    return value.strftime(fmt)
