from logging.config import dictConfig
import os
from flask import Flask, Blueprint
from flask_migrate import Migrate
from flask_restx import Api
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from yaml import safe_load

from common.errors import *
from common.utils import str_reader

'''
Flask 앱이 이 곳에서 init되어 필요한 component들을 
init_app에서 initialize하여 플라스크 웹엔진에
로드가 되도록 한다.
'''
#import pandas as pd
#import bigdataquery as bdq
#import datetime
'''
Bigdataquarry를 불러오는 component
'''

db = SQLAlchemy()
migrate = Migrate()
csrf = CSRFProtect()
api = Api(doc='/apidocs', version='1.0',
          title='Boilerplate Flask API', description='-')

config_yaml = safe_load(str_reader('./config.yaml'))


if not os.path.isdir('/config/work/sharedworkspace/logs'):
    os.makedirs('/config/work/sharedworkspace/logs')


dictConfig({
    'version': 1,
    'formatters': {
        'simple': {
            'format': '[%(asctime)s] %(levelname)s %(message)s',
        },
        'verbose': {
            'format': "[%(asctime)s] %(levelname)s [%(name)s:%(lineno)s] %(message)s",
            'datefmt': "%Y-%m-%d %H:%M:%S"
        },
    },
    'handlers': {
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
        'file': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': '/config/work/sharedworkspace/logs/boilerplate-flask.log',
            'maxBytes': 1024 * 1024,
            'backupCount': 5,
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['console', 'file'],
        'level': 'DEBUG',
    }
})


def create_app():
    '''
    정의된 모델과 views & api를 Flask app에
    register 한 뒤에 Flask 앱을 run하기 전 상태로
    준비시켜 준다.
    '''
    app = Flask(__name__)
    app.secret_key = config_yaml['secret_key']

    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_DATABASE_URI'] = config_yaml['SQLALCHEMY_DATABASE_URI']['sqlite']

    # Blueprint
    from views import home, memo, stat, timeline
    app.register_blueprint(home.bp)
    app.register_blueprint(memo.bp)
    app.register_blueprint(stat.bp)
    app.register_blueprint(timeline.bp)

    # REST API
    api_bp = Blueprint('api', __name__, url_prefix='/api/v1')
    app.register_blueprint(api_bp)

    # ORM
    from models import db
    db.init_app(app)
    migrate.init_app(app, db)
    api.init_app(app)
    csrf.init_app(app)

    # REST API
    from api.v1.voc import ns

    # 필터
    from common.filter import format_datetime
    app.jinja_env.filters['datetime'] = format_datetime

    from common import errors
    app.register_blueprint(errors.bp)

    return app
