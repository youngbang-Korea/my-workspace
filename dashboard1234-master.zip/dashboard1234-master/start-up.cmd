@echo off
@set FLASK_APP=app
@set FLASK_DEBUG=true
flask run -h 127.0.0.1 -p 8080 --no-reload
