from app import db
from datetime import datetime

'''
Voc 모델을 정의

title - 제목
content - 내용
status - voc 상태
type - voc 타입
'''


class Voc(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.now())
    updated_at = db.Column(db.DateTime, onupdate=datetime.now())
    title = db.Column(db.String(128))
    content = db.Column(db.Text)
    status = db.Column(db.String(50))
    type = db.Column(db.String(50))
