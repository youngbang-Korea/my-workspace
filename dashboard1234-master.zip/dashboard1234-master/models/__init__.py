'''
정의된 모델을 이곳으로 import한 후에 
app/__init__.py로 다시 import하여 Flask에 반영
'''

from models.memo import db
from models.comment import db
from models.voc import db
