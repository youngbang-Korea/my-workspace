from app import db
from datetime import datetime

'''
Memo 모델을 정의

title - 제목
contents - 내용
comments - 메모에 외래키로 저장되는 댓글
'''


class Memo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.now())
    updated_at = db.Column(db.DateTime, onupdate=datetime.now())
    title = db.Column(db.String(128))
    contents = db.Column(db.Text)
    comments = db.relationship(
        'Comment', backref='memo', lazy='joined', cascade="all, delete-orphan")
