from app import db
from datetime import datetime

'''
Comment 모델을 정의

comment - 댓글 내용
memo_id - 참조하고 있는 Memo테이블의 id
'''


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.now())
    comment = db.Column(db.String(512))
    memo_id = db.Column(db.Integer, db.ForeignKey('memo.id'))
