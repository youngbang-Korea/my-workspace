from datetime import datetime
from app import api, db
from models.voc import Voc
from flask_restx import Resource, fields


'''
VOC에 관한 REST API를 개발하기 위해 
Flask-RESTX 파이썬 패키지를 사용.
Swagger를 사용하여 REST API 문서화 지원.
'''

ns = api.namespace('api/v1/voc', description='VOC REST API')

voc = api.model('Voc', {
    'id': fields.Integer(readonly=True, description='The voc unique identifier'),
    'created_at': fields.String(description='The voc created_at'),
    'updated_at': fields.String(description='The voc updated_at'),
    'title': fields.String(description='The voc title'),
    'content': fields.String(description='The voc content'),
    'status': fields.String(description='The voc status'),
    'type': fields.String(description='The voc type')
})


class VocDAO:

    def read(self, id):
        if id:
            voc = Voc.query.filter_by(id=id).first()
        else:
            voc = Voc.query.all()
        if voc:
            return voc
        else:
            api.abort(404, "VOC {} doesn't exist".format(id))

    def create(self, data):
        voc = Voc(**data)
        voc.created_at = datetime.now()
        voc.updated_at = datetime.now()
        db.session.add(voc)
        db.session.commit()
        return voc

    def update(self, id, data):
        voc = Voc.query.filter_by(id=id).first()
        voc.updated_at = datetime.now()
        voc.title = data['title'] if 'title' in data.keys() else voc.title
        voc.content = data['content'] if 'content' in data.keys(
        ) else voc.contents
        voc.status = data['status'] if 'status' in data.keys() else voc.status
        voc.type = data['type'] if 'type' in data.keys() else voc.type
        db.session.commit()
        return voc

    def delete(self, id):
        voc = Voc.query.filter_by(id=id).first()
        db.session.delete(voc)
        db.session.commit()


DAO = VocDAO()


@ns.route('/')
class VocList(Resource):
    @ns.doc('list_vocs')
    @ns.marshal_list_with(voc)
    def get(self):
        return DAO.read(None)

    @ns.doc('create_voc')
    @ns.expect(voc)
    @ns.marshal_with(voc, code=201)
    def post(self):
        return DAO.create(api.payload), 201


@ns.route('/<int:id>')
@ns.response(404, 'VOC Not Found')
@ns.param('id', 'The voc identifier')
class VocResource(Resource):
    @ns.doc('get_voc')
    @ns.marshal_with(voc)
    def get(self, id):
        return DAO.read(id)

    @ns.doc('delete_voc')
    @ns.response(204, 'VOC Deleted')
    def delete(self, id):
        DAO.delete(id)
        return '', 204

    @ns.expect(voc)
    @ns.marshal_with(voc)
    def put(self, id):
        return DAO.update(id, api.payload)
