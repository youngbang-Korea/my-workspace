from flask import Blueprint, redirect, render_template, request, url_for, current_app

from app import db
from forms.memo import MemoForm
from models.memo import Memo
from services.memo import *

'''
Memo에 대한 view를 정의
'''


bp = Blueprint('memo', __name__, url_prefix='/memo')


@bp.route("/", methods=['GET', 'POST'])
@bp.route("/list", methods=['GET', 'POST'])
def _list():
    '''
    Memo 데이터를 수정 & 삭제 가능하도록
    리스트 형태로 가져올 수 있도록 하는
    부분
    '''
    search = request.args.get('search', type=str, default='')
    page = request.args.get('page', type=int, default=1)
    new = request.args.get('new', type=int, default=0)

    form = MemoForm()
    if request.method == 'GET':
        return memo_search_view(form, search, page, new)
    elif request.method == 'POST':
        return memo_delete(request, form, search, page)


@bp.route("/<memo_id>", methods=['GET', 'POST'])
def memo(memo_id):
    '''
    Memo에 대해 Delete를 제외한 Read, Create, Update를
    할 수 있도록 orm logic이 import되어 memo데이터를 생성, 수정, 읽기
    에 관여하는 함수.
    '''
    res = None
    form = MemoForm()
    if request.method == 'GET':
        res = response_from_view(form, memo_id)
    elif request.method == 'POST':
        res = request_to_db(form, request, memo_id)
    return res
