from flask import Blueprint, redirect, render_template, request, url_for

from app import db
from forms.comment import CommentForm
from models.memo import Memo
from services.comment import comment_create
from services.memo import *


'''
Timeline에 대한 view를 정의
'''

bp = Blueprint('timeline', __name__, url_prefix='/timeline')


@bp.route("/", methods=['GET', 'POST'])
def index():
    '''
    Memo의 제목, 내용을 template에 render해주는 부분.
    join되어 있는 comment 테이블의 데이터 또한 memo_id에 따라
    각각 가지고 와서 template에 rendering.
    '''
    form = CommentForm()
    if request.method == 'GET':
        memo_queryset = Memo.query.options(db.joinedload(
            Memo.comments)).order_by(Memo.id.desc()).limit(20).all()
        return render_template('timeline/timeline.html', memo_list=memo_queryset, form=form), 200
    elif request.method == 'POST':
        comment_create(form.comment.data, request.form['memo_id'])
        return redirect('{}/#memo_id_{}'.format(
            url_for('timeline.index'), request.form['memo_id']))
