from flask import Blueprint, redirect, url_for

'''
Home에 대한 view를 정의
'''

bp = Blueprint('home', __name__, url_prefix='/')


@bp.route('/')
def index():
    '''
    메모 리스트로 이동
    '''
    return redirect(url_for('memo._list'))
