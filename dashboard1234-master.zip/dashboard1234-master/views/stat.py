from flask import Blueprint, render_template, request

from models.comment import Comment
from models.memo import Memo

'''
통계(stat)에 대한 view를 정의
'''

bp = Blueprint('stat', __name__, url_prefix='/stat')


@bp.route("/", methods=['GET'])
def index():
    if request.method == 'GET':
        total_memo = Memo.query.all()
        total_comment = Comment.query.all()
        stat1 = 10  # 화면 표시를 위한 임의값
        stat2 = 20  # 화면 표시를 위한 임의값
        return render_template('stat/stat.html', total_memo=total_memo, total_comment=total_comment, stat1=stat1, stat2=stat2), 200
