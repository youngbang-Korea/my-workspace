from flask import redirect, render_template, url_for
from datetime import datetime

from app import db, config_yaml
from models.memo import Memo

'''
memo service 처리와 관련된 함수를 관리한다.
'''


def memo_search_view(form, search, page, new):
    '''
    memo 검색 로직을 템플릿에 렌더링한다.
    '''
    if search:
        keyword = '%%{}%%'.format(search)
        memo_queryset = Memo.query.order_by(Memo.id.desc()) \
            .filter(Memo.title.ilike(keyword) |  # 질문제목
                    Memo.contents.ilike(keyword)  # 질문내용
                    ) \
            .distinct()
        if new:
            page = 1
    else:
        memo_queryset = Memo.query.order_by(Memo.id.desc())

    page_cnt = (memo_queryset.count() / config_yaml['PAGINATION_PER_PAGE']) + 1
    if page_cnt != 1.0 and page_cnt <= page:
        page -= 1

    memo_queryset = memo_queryset.paginate(
        page=page, per_page=config_yaml['PAGINATION_PER_PAGE'])
    return render_template('memo/memo_list.html', form=form, page=page, memo_list=memo_queryset, search=search), 200


def memo_create_view(form):
    '''
    memo 생성 로직을 템플릿에 렌더링한다.
    '''
    return render_template('memo/memo_edit.html', form=form, method='POST'), 200


def memo_edit_view(form, memo_id):
    '''
    memo_id 기준으로 수정 로직을 템플릿에 렌더링한다.
    '''
    try:
        memo_queryset = Memo.query.filter_by(id=memo_id).first()
        form.title.data = memo_queryset.title
        form.contents.data = memo_queryset.contents
    except:
        return render_template('error/500.html', form=form, method='PUT'), 500
    else:
        return render_template('memo/memo_edit.html', form=form, method='PUT'), 200


def response_from_view(form, memo_id):
    '''
    memo를 view 기준으로 생성 또는 수정 로직을 템플릿에 렌더링한다.
    '''
    res = None
    if memo_id == 'new':
        res = memo_create_view(form)
    else:
        res = memo_edit_view(form, memo_id)
    return res


def data_form_request(form, request):
    '''
    form에서 수집된 memo 데이터를 정제한다.
    '''
    title = form.title.data if form.title.data else None
    contents = form.contents.data if form.contents.data else None
    method = request.form.get('method')
    return title, contents, method


def memo_create(form, title, contents):
    '''
    memo create에 관여하는 orm으로써
    title과, content를 필수로 입력해 주어야 한다.
    '''
    if form.validate_on_submit():
        memo = Memo(title=title, contents=contents,
                    created_at=datetime.now(), updated_at=datetime.now())
        db.session.add(memo)
        db.session.commit()
        return redirect(url_for('memo._list'))
    else:
        return render_template('memo/memo_edit.html', form=form, method='POST')


def memo_update(form, memo_id, title, contents):
    '''
    이미 적재되어 있는 memo row 데이터를 memo_id를 
    기준으로 인덱싱하여 orm queryset형태로 가져온 뒤
    존재한다면 업데이트를 진행하는 orm이다.
    '''
    if form.validate_on_submit():
        memo_queryset = Memo.query.filter_by(id=memo_id).first()
        memo_queryset.title = title if title else memo_queryset.title
        memo_queryset.contents = contents if contents else memo_queryset.contents
        memo_queryset.updated_at = datetime.now()
        db.session.commit()
        return redirect(url_for('memo._list'))
    else:
        return render_template('memo/memo_edit.html', form=form, method='PUT'), 200


def memo_delete(request, form, search, page):
    '''
    이미 적재되어 있는 memo row 데이터를 memo_id를
    기준으로 인덱싱하여 orm queryset형태로 가져온 뒤
    존재한다면 삭제를 진행하는 orm이다.
    '''
    memo_id_list = list(request.form.getlist('_selected_'))
    if memo_queryset := Memo.query.filter(Memo.id.in_(memo_id_list)).all():
        for memo in memo_queryset:
            db.session.delete(memo)
        db.session.commit()
    return memo_search_view(form, search, page, 0)


def request_to_db(form, request, memo_id):
    res = None
    title, contents, method = data_form_request(form, request)
    if method == 'POST':
        res = memo_create(form, title, contents)
    elif method == 'PUT':
        res = memo_update(form, memo_id, title, contents)
    return res
