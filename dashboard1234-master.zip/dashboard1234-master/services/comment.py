from datetime import datetime

from app import db
from models.comment import Comment

'''
댓글 생성 시에 ORM 클래스를 생성하여 DB에 적재한다.
'''


def comment_create(comment, memo_id):
    '''
    댓글 내용과 댓글이 게재될 memo_id를 
    인자로 받은 뒤 db에 row 데이터를 create한다.
    '''
    memo = Comment(comment=comment,
                   created_at=datetime.now(), memo_id=memo_id)
    db.session.add(memo)
    db.session.commit()
