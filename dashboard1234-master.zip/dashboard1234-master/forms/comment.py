from flask_wtf import FlaskForm
from wtforms import StringField

'''
FlaskForm은 사용자로부터 입력 양식을 제공하기 위해 사용한다.
'''


class CommentForm(FlaskForm):
    comment = StringField('댓글')
