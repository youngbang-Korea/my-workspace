from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms.validators import DataRequired

'''
FlaskForm은 사용자로부터 입력 양식을 제공하기 위해 사용한다.
validators를 지정하면 데이터에 대해 지정한 방식으로 검증을 할 수 있다.
'''


class MemoForm(FlaskForm):
    title = StringField('제목', validators=[DataRequired('제목은 필수입력입니다.')])
    contents = TextAreaField(
        '내용', validators=[DataRequired('내용은 필수입력입니다.')])
